(function(angular, $, _) {
  angular.module('crmCxn').controller('CrmCxnConfirmAboutCtrl', function($scope) {
    $scope.ts = CRM.ts(null);
  });
})(angular, CRM.$, CRM._);
