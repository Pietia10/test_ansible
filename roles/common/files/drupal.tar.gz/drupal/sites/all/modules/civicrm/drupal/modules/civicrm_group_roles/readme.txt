This module provides two-way synchronization between Drupal Roles and CiviCRM based on rules defined by the administrator.

Note that for now, removing from a Role does NOT remove the user from the CiviCRM group, so be sure to remove them manually from the group if you need to do so.

Original Author: Matt Chapman - http://drupal.org/user/143172

For support & feature requests, please visit http://forum.civicrm.org/
