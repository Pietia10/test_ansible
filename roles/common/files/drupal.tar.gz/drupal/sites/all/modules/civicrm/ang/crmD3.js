(function (angular, $, _) {
  // thin stub for declaring dependencies
  angular.module('crmD3', []);
})(angular, CRM.$, CRM._);
