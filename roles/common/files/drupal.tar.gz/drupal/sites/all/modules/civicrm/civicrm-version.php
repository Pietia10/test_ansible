<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.7.16',
                'cms'      => 'Drupal',
                'revision' => '49b3bee36e' );
}

